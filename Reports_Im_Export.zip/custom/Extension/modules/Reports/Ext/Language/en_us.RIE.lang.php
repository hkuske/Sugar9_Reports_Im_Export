<?php
$mod_strings['LNK_IMPORT_REPORTS'] = 'Import Reports';
