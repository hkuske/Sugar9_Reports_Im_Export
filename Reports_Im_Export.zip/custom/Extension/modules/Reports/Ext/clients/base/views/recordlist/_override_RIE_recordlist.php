<?php
$viewdefs['Reports']['base']['view']['recordlist']['selection']['actions'][] = 
            array(
                'name' => 'export_button',
                'type' => 'button',
                'label' => 'LBL_EXPORT',
                'acl_action' => 'export',
                'primary' => true,
                'events' => array(
                    'click' => 'list:massexport:fire',
                ),
            );
