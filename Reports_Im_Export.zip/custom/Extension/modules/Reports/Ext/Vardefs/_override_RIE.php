<?php
//REPORTS_IM_EXPORT
$dictionary['SavedReport']['importable'] = true;
